#ifndef _STDLIBCORE_H_
#define _STDLIBCORE_H_
#ifndef __AUTODEPEND__
#ifndef BYPASS_RPC_DEFS
#ifdef WIN32
#include <rpc.h>
#else
#include <rpc/rpc.h>
#endif
#endif // BYPASS_RPC_DEFS
#endif //autodepend

// HACK HACK HACK strtoul isn't portable, and redefining it breaks the SunOS build
 /* Solaris machines use signed longs, so call their unsigned
	long function. */
//#ifndef WIN32
//#define strtol			strtoul
//#endif

/* Defines for rpc. */
#define progNum			0x20000000
#define versNum			0x1

#define sendProcNum		1

#define etxToken		3
#define colonToken		':'

#define hexStrLen		10

/* Verify connection of socket with a test string. */
#define SOCKET_TEST_STRING  "bill steinmetz"

/* Name of + Verilog command line option to send socket name. */
#define SOCKET_PLUS_ARG		"PLIStream"
#define SOCKET_MINUS_ARG	"tstStream"

/* Name of + Verilog command line option to send num of streams. */
#define NUMSTREAMS_PLUS_ARG	"numStreams"

/* Delay for rpc timeout. */
#define timeOutDelaySend		600
#define timeOutDelaySecRecv		600
#define timeOutDelayUSecRecv	0

/* General transaction type defines. */
#define byte1		1
#define halfWrd		2
#define wrd			4
 
#define byteMsk		0xff
#define halfWrdMsk	0xffff
#define wrdMsk		0xffffffff

/* Command type masks and bit defines. */
#define comTypMsk		0x000000ff
#define ackMsk			0x00000080
#define asyncMsk		0x00000020
#define closeSocketMsk	0x00000010
#define serverCmdMsk	0x00000001
#define burstSizeMsk	0x000fff00
#define burstSizeShift	8
#define opMsk			0xfff00000

#define ack				0x00000080
#define serverAck		0x00000040
#define async			0x00000020
#define closeSocket		0x00000010
#define serverCmd		0x00000001

/* Server commands.  Command follows socket command. */
#define	reqPacket		0x00000001
#define connect			0x00000002
#define intBlockSet		0x00000003

/* streamPacket structure contains information
	that will be transmitted across the socket. */
typedef struct streamPacketCell
{
	unsigned int cmd;
	int argc;
	char **argv;
} streamPacketStructType, *streamPacketPtrType;

typedef struct ctxCell
{
	unsigned char rdyForRd;
	streamPacketPtrType streamPacketPtr;
	struct ctxCell *next;
} ctxStructType, *ctxPtrType;

typedef struct streamCell
{
#ifdef WIN32
    int *client;
	int *xprtHdl;
#else
    CLIENT *client;
	SVCXPRT *xprtHdl;
#endif
	int FD;
	unsigned int errCnt;
	/* Flags:
		rdyForRd:  opposite stream has already sent a reply and
			the packet is waiting for immediate return.
		waitForRd:  opposite stream has not sent a reply so
			wait for a return packet.
		close:  stream is closing.
		flush:  send packet with sendreply.
		reqCnt:  number of packet requests.
		bounce:  if set then always bounce back a null packet.
		blocked:  if set then the current stream pair has intBlock set
			and the opposite stream is blocked and waiting for a return packet.
		intBlock:  if set then the client will wait until all interrupts
			have concluded.  The client blocks until the final reverse
			context switch.
		saveInFirstCtx:  if set then the next send packet is not sent
			to the destination stream but instead to the destination stream
			first context.  If set and a packet request is received, clear
			this flag.  This flag is only valid during interrupt handling.
		ctxCnt:  number of recursive context switches. 
	*/
	unsigned char rdyForRd, waitForRd, close, flush, bounce, blocked, intBlock;
	unsigned char saveInFirstCtx;
	unsigned int reqCnt;
	int ctxCnt;
	char *progName;
	streamPacketPtrType streamPacketPtr;
	/* oneCtxPtr points to a queue of contexts.  firstCtxPtr points to
		the first element placed in the queue. */
	ctxPtrType ctxPtr, firstCtxPtr;
} streamStructType, *streamPtrType, **streamArrayPtrType;

/* Globals. */
extern streamArrayPtrType gblStreamArrayPtr;

/* Pointer to an async function. */
extern void (* asyncFtnPtr) ();

extern streamPacketPtrType IniStreamPacketPtr ();
extern streamPtrType IniStreamPtr ();
extern streamArrayPtrType IniStreamArrayPtr ();
extern streamArrayPtrType UpdateStreamArrayPtr ();
extern void FreeStreamPacketPtr ();
extern void SetIntBlock ();
extern int ConnectSocket ();
extern void SendSocket ();
extern void SetReceiveBlk ();
extern streamPacketPtrType ReceiveSocket ();
extern void CopyStreamPacket ();
extern streamPacketPtrType BuildSocketPacketCommand ();
extern streamPacketPtrType BuildSocketPacketInteger ();
extern streamPacketPtrType BuildSocketPacketString ();
#if defined(SUNOS) || defined(M64)
    extern unsigned int ExtractSocketPacketCommand (unsigned int sock);
#else
    extern unsigned int ExtractSocketPacketCommand ();
#endif
extern unsigned int ExtractSocketPacketInteger ();
extern char *ExtractSocketPacketString ();
extern char *ExtractTstSocket ();
extern void SetProgramName ();
extern char *ExtractProgramName ();
extern int ExtractErrCnt ();
extern void IncErrCnt ();
extern void CloseSocket ();
extern streamPacketPtrType ConvertStr2Packet ();
extern char *ConvertPacket2Str ();

#endif /* #ifndef _STDLIBCORE_H_ */
