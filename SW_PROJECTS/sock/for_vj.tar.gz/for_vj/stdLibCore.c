
#include <sys/types.h>
#if defined(WIN32)
	#include <rpc.h>
#else
	#include <rpc/rpc.h>
#endif
#include <stdio.h>
#include <string.h>

#include "UstdLib.h"
#include "unistd.h"
#include "stdLibCore.h"
#include "XDRProc.h"

//#define DEBUG 1
 
/*--------------------------------------------------*/
/* Globals. */
streamArrayPtrType gblStreamArrayPtr;

/* Flag that determines if ReceiveSocket blocks. */
static unsigned char gblBlk = TRUE;

/* Pointer to an async function. */
void (* asyncFtnPtr) () = (void (*) ()) NULL;

/*--------------------------------------------------*/
/* Calloc space for streamPacketPtr. */

streamPacketPtrType
IniStreamPacketPtr (progName)
char *progName;

{
	streamPacketPtrType streamPacketPtr;

	if ((streamPacketPtr = (streamPacketPtrType) calloc (1, sizeof 
		(streamPacketStructType))) == (streamPacketPtrType) NULL)
	{
		fprintf (stderr,
			"Error: %s:  Can't allocate memory for streamPacketPtr.\n",
			progName);
		fflush (stderr);
		exit (1);
	}

	return (streamPacketPtr);
}

/*--------------------------------------------------*/
/* Calloc space for streamPtr, an element of gblStreamArrayPtr
	containing ptrs to stream packets, program name, and stream 
	identifier. */

streamPtrType
IniStreamPtr (progName)
char *progName;

{
	streamPtrType streamPtr;

	if ((streamPtr = (streamPtrType) calloc (1, sizeof 
		(streamStructType))) == (streamPtrType) NULL)
	{
		fprintf (stderr,
			"Error:  %s:  Can't allocate memory for streamPtr.\n",
				progName);
		fflush (stderr);
		exit (1);
	}

	streamPtr -> streamPacketPtr = IniStreamPacketPtr (progName);

	return (streamPtr);
}

/*--------------------------------------------------*/
/* Calloc space for gblStreamArrayPtr, a global array of pointers to
	stream information. */

streamArrayPtrType
IniStreamArrayPtr (progName, numSocket)
char *progName;
int numSocket;

{
	streamArrayPtrType localStreamArrayPtr;
	int i;

	/* Initialize the entire list. */
	if ((localStreamArrayPtr = (streamArrayPtrType) calloc (numSocket, sizeof 
		(streamPtrType))) == (streamArrayPtrType) NULL)
	{
		fprintf (stderr,
			"Error:  %s:  Can't allocate memory for streamArrayPtr.\n",
			progName);
		fflush (stderr);
		exit (1);
	}

	return (localStreamArrayPtr);
}

/*--------------------------------------------------*/
/* Realloc space for streamArrayPtr, a global ptr to the socket's
	read and write file ptrs.  This function handles reallocs
	of one cell at a time. */

streamArrayPtrType
UpdateStreamArrayPtr (progName, localStreamArrayPtr, numSocket)
char *progName;
streamArrayPtrType localStreamArrayPtr;
int numSocket;

{
	/* Reinitialize the entire list. */
	if ((localStreamArrayPtr = (streamArrayPtrType) realloc (
		localStreamArrayPtr, sizeof (streamPtrType) * numSocket)) ==
		(streamArrayPtrType) NULL)
	{
		fprintf (stderr,
			"Error: %s:  Can't reallocate memory for streamArrayPtr.\n",
			progName);
		fflush (stderr);
		exit (1);
	}

	return (localStreamArrayPtr);
}

/*--------------------------------------------------*/
/* Clear up streamPacketPtr. */

void
FreeStreamPacketPtr (streamPacketPtr)
streamPacketPtrType streamPacketPtr;

{
	int i;

	if (streamPacketPtr)
	{
		FreeStrArray (streamPacketPtr -> argv, streamPacketPtr -> argc);
		streamPacketPtr -> argv = (char **) NULL;

		free (streamPacketPtr);
	}

}


/*--------------------------------------------------*/
/* Clear up streamArrayPtr element. */

void
FreeStreamArrayPtrEle (socketId)
unsigned int socketId;

{
	/* Free up streamPacketPtr. */
	FreeStreamPacketPtr (gblStreamArrayPtr [socketId] -> streamPacketPtr);
	gblStreamArrayPtr [socketId] -> streamPacketPtr = (streamPacketPtrType)
		NULL;
	
	/* Free up the program name. */
	free (gblStreamArrayPtr [socketId] -> progName);
	gblStreamArrayPtr [socketId] -> progName = (char *) NULL;

	/* Free up the element. */
	free (gblStreamArrayPtr [socketId]);
	gblStreamArrayPtr [socketId] = (streamPtrType) NULL;
}

/*--------------------------------------------------*/
/* Allow each test to en/disable interrupt blocking.  The
	default is to disable interrupt blocking.  When
	an interrupt occurs, streams with blocking disabled
	will continue to execute commands.  Streams with
	blocking enabled will only execute commands from the
	interrupt handler. */

void
SetIntBlock (streamId, flag)
unsigned int streamId;
unsigned char flag;

{
	BuildSocketPacketCommand (streamId,
		(2 << burstSizeShift) | serverCmd);
	BuildSocketPacketInteger (streamId, 0, intBlockSet);
	BuildSocketPacketInteger (streamId, 1, flag);
	SendSocket (streamId);
	
	ReceiveSocket (streamId);
}

/*--------------------------------------------------*/
/* Link to one connectiont.  Return a 
	stream identifier to the connection.  Only child
	processes can use this function.  Secondly, 
	verify the socket connection by receiving and
	sending a test string. */

int 
ConnectSocket (streamName, progName)
char *streamName, *progName;

{
	int s, i; 
	static int streamArrayIdx = 0;
	unsigned int uniqueProgNum;
	char *strPtr;
	char tmpChar, *tmpCharPtr;

	/* Break up streamName into host and programNum. */
	if ((strPtr = strchr (streamName, colonToken)) == (char *) NULL)
	{
		fprintf (stderr,
			"Error:  %s:  search for %c in streamName failed!\n", progName,
				colonToken);
		exit (1);
	}
	/* Save delimiter location. */
	tmpCharPtr = strPtr;
	tmpChar = *tmpCharPtr;

	*strPtr++ = '\0';
	uniqueProgNum = strtol (strPtr, (char **) NULL, 16);

	/* Set up gblStreamArrayPtr structure for each element. */
	if (streamArrayIdx == 0)
	{
		gblStreamArrayPtr = IniStreamArrayPtr (progName, streamArrayIdx + 1);

		/* Initialize the first element of the list. */
		gblStreamArrayPtr [streamArrayIdx] = IniStreamPtr (progName);
	}
	else
	{
		/* Add one more element into gblStreamArrayPtr. */
		gblStreamArrayPtr = UpdateStreamArrayPtr (progName, gblStreamArrayPtr,
			streamArrayIdx + 1);
		gblStreamArrayPtr [streamArrayIdx] = IniStreamPtr (progName);
	}

	if ((gblStreamArrayPtr [streamArrayIdx] -> client =
		clnt_create (streamName, uniqueProgNum, versNum, "tcp")) ==
		(CLIENT *) NULL)
	{
		fprintf (stderr,
			"Error:  %s:  clnt_create failed!\n", progName);
		fflush (stderr);
		exit (1);
	}


	SetProgramName (streamArrayIdx, progName);

#	ifdef TESTCON
	/* Test out connection.  Send out a test packet and wait for a return. */
	BuildSocketPacketCommand (streamArrayIdx,
		(2 << burstSizeShift) | serverCmd);
	BuildSocketPacketInteger (streamArrayIdx, 0, connect);
	BuildSocketPacketString (streamArrayIdx, 1, SOCKET_TEST_STRING);
	SendSocket (streamArrayIdx);
	
	ReceiveSocket (streamArrayIdx);

	if (strcmp (SOCKET_TEST_STRING,
		ExtractSocketPacketString (streamArrayIdx, 0)))
	{
		fprintf (stderr, "%s:  Socket packet test failed.\n",
		ExtractProgramName (streamArrayIdx));
		fflush (stderr);
	}
#	endif

	/* Replace delimiter. */
	*tmpCharPtr = tmpChar;

	return (streamArrayIdx++);
}

/*--------------------------------------------------*/
/* Save the contents of streamPacketPtr into a new
	pointer. */

void
SaveStreamPacket (toStreamPacketPtr, streamPacketPtr)
streamPacketPtrType toStreamPacketPtr, streamPacketPtr;

{
	int i;

	toStreamPacketPtr -> cmd = streamPacketPtr -> cmd;

	/* Free up the old array elements. */
	FreeStrArray (toStreamPacketPtr -> argv, toStreamPacketPtr ->
		argc);
	toStreamPacketPtr -> argv = (char **) NULL;

	toStreamPacketPtr -> argc = streamPacketPtr -> argc;

	if (toStreamPacketPtr -> argc)
	{
		toStreamPacketPtr->argv = IniStrArray( toStreamPacketPtr->argc );

		for (i = 0; i < toStreamPacketPtr -> argc; i++)
        {
#       ifdef DEBUG
            if (!streamPacketPtr->argv[i]) fprintf( stderr, "dispatch!%s(%d): streamPacketPtr->argv[%d] = NULL\n", __FILE__, __LINE__, i );
#       endif
			toStreamPacketPtr->argv[i] = strdup( streamPacketPtr->argv[i] ? streamPacketPtr->argv[i] : "" );
        }

	}
}

/*--------------------------------------------------*/
/* Debug information on a send or a receive. */

void
DbgInfo (streamId, streamPacketPtr, dirStrPtr)
unsigned int streamId;
streamPacketPtrType streamPacketPtr;
char *dirStrPtr;

{
#	ifdef DEBUG
	int i;

	fprintf (stdout, "%s:  %s - command (0x%x) - argc = (0x%x)", 
		ExtractProgramName (streamId), dirStrPtr, streamPacketPtr -> cmd, streamPacketPtr -> argc);

	for (i = 0; i < streamPacketPtr -> argc; i++)
	{
		fprintf (stdout, " - argv [%d] (%s)", i, streamPacketPtr ->
			argv [i]);
	}

	fprintf (stdout, "\n");
	fflush (stdout);

#	endif

#ifdef DUMP_ULT
// This is come code from when I (Paul MacDougal)
// was dumping ultra-low traces of display tests.
//  extern FILE *socket_dump_file;
    if (NULL != socket_dump_file)
    {
        int i;
        fprintf(socket_dump_file, "%s 0x%x %d\n", 
            dirStrPtr, streamPacketPtr->cmd, streamPacketPtr->argc);

        for (i=0; i < streamPacketPtr->argc; i++)
        {
            fprintf(socket_dump_file, "%s\n", streamPacketPtr->argv[i]);
        }
    }
#endif
}

/*--------------------------------------------------*/
/* Send a command and any data across the socket. */

void
SendSocket (streamId)
int streamId;

{
	streamPtrType streamPtr = gblStreamArrayPtr [streamId];
	streamPacketPtrType streamPacketPtr;
	enum clnt_stat clientStat;
	char *strPtr, *ackStrPtr;
	static struct timeval timeOut = {timeOutDelaySend, 0};
	int i;

	strPtr = ConvertPacket2Str (streamPtr -> streamPacketPtr);

	DbgInfo (streamId, streamPtr -> streamPacketPtr, "Send");
	ackStrPtr = (char *) NULL;

	/* Set the timeout. */
	if (!clnt_control (gblStreamArrayPtr [streamId] -> client,
		CLSET_TIMEOUT, (char *) &timeOut))
	{
		fprintf (stderr,
			"Error:  %s:  clnt_control failed!\n",
			ExtractProgramName (streamId));
		fflush (stderr);
		exit (1);
	}

	clientStat = clnt_call (streamPtr -> client, sendProcNum, XDRStr,
		(char *) &strPtr, XDRStr, (char *) &ackStrPtr, timeOut);

	if (clientStat)
	{
		clnt_perrno (clientStat);
		exit (1);
	}

	/* Save packet. */
	streamPacketPtr = ConvertStr2Packet (streamPtr -> progName, ackStrPtr);
	SaveStreamPacket (streamPtr -> streamPacketPtr, streamPacketPtr);
	FreeStreamPacketPtr (streamPacketPtr);

	if (! (ExtractSocketPacketCommand (streamId) & serverAck))
	{
		fprintf (stderr,
			"Error:  %s:  Unexpected acknowledgement in SendSocket.\n",
			ExtractProgramName (streamId));
		exit (1);
	}

	/* Already saved ack string as a packet, so free it. */
	clnt_freeres (streamPtr -> client, XDRStr, (char *) &ackStrPtr);

	/* String is already sent, so free it. */
	free (strPtr);

}

/*--------------------------------------------------*/
/* Set the gblBlk variable. */

void
SetReceiveBlk (flag)
unsigned char flag;

{
	gblBlk = flag;
}

/*--------------------------------------------------*/
/* Wait for a command and any data to be sent across the
	socket.  Place socket transaction information in the 
	socket_packet structure. */

streamPacketPtrType
ReceiveSocket (streamId)
int streamId;

{
    static int once = 1;
	streamPtrType streamPtr = gblStreamArrayPtr [streamId];
	streamPacketPtrType streamPacketPtr;
	enum clnt_stat clientStat;
	char *strPtr, *ackStrPtr;
	unsigned char blk = TRUE;
	static struct timeval timeOut = {60,0}; // 1 minute
	int i, receiveAPacket = TRUE;
    unsigned int retryCount = 0;
    static unsigned int maxRetryCount = 3;

    if (once)
    {
        once = 0;
        if (getenv("INTERACTIVE_DEBUG")) maxRetryCount = ~0u;
    }

	/* Build request command. */
	BuildSocketPacketCommand (streamId, (1 << burstSizeShift) | serverCmd);
	BuildSocketPacketInteger (streamId, 0, reqPacket);

	strPtr = ConvertPacket2Str (streamPtr -> streamPacketPtr);

	/* Keep receiving until all interrupts are cleared and this function
		is ready to hand back a packet to the calling function. */
	while (receiveAPacket)
	{
		/* Loop until a serverAck is not received. */
		while (blk)
		{
			ackStrPtr = (char *) NULL;

			/* Set the timeout. */
			if (!clnt_control (gblStreamArrayPtr [streamId] -> client,
				CLSET_TIMEOUT, (char *) &timeOut))
			{
				fprintf (stderr,
					"Error:  %s:  clnt_control failed!\n", 
						ExtractProgramName (streamId));
				fflush (stderr);
				exit (1);
			}

			clientStat = clnt_call (streamPtr -> client, sendProcNum, XDRStr,
				(char *) &strPtr, XDRStr, (char *) &ackStrPtr, timeOut);

			/* Try again on a timeout. */
			if (clientStat && (clientStat != RPC_TIMEDOUT))
			{
				clnt_perrno (clientStat);
				exit (1);
			}

			if (clientStat != RPC_TIMEDOUT)
			{
				/* Save packet. */
				streamPacketPtr = ConvertStr2Packet (streamPtr -> progName,
					ackStrPtr);
				SaveStreamPacket (streamPtr -> streamPacketPtr,
					streamPacketPtr);
				FreeStreamPacketPtr (streamPacketPtr);

				/* If serverAck is not received. */
				if (! (ExtractSocketPacketCommand (streamId) & serverAck))
					blk = FALSE;
			}
			else
			{
#				ifdef DEBUG
				fprintf (stdout, "%s:  timeout!\n",
					ExtractProgramName (streamId));
				fflush (stdout);
#				endif

                if (++retryCount > maxRetryCount)
                {
                    fprintf(stderr, "%s: Too many timeout retries:\n",
                            ExtractProgramName (streamId) );
                    exit(1);
                }

				/* If not blocking on a timeout, return a blank command. */
				if (! (blk = gblBlk))
					BuildSocketPacketCommand (streamId, 0x0);

			}

			/* Free string for next time around. */
			if (ackStrPtr)
				clnt_freeres (streamPtr -> client, XDRStr, (char *) &ackStrPtr);

		}

		DbgInfo (streamId, streamPtr -> streamPacketPtr, "Recv");


		/* If an async function has been specified and the command word
			contains an async and an ack command. */
		if ((asyncFtnPtr != (void (*) ()) NULL) && (streamPtr ->
			streamPacketPtr -> cmd & asyncMsk))
		{
			/* Call the function. */
			(* asyncFtnPtr) (streamId);

			/* Block for the first clnt_call. */
			blk = TRUE;

			/* Receive the next packet. */
			receiveAPacket = TRUE;
		}
		/* An async command without an async function. */
		else if ((asyncFtnPtr == (void (*) ()) NULL) && (streamPtr ->
			streamPacketPtr -> cmd & asyncMsk))
		{
			/* For now just perform another receive. */
			/* Block for the first clnt_call. */
			blk = TRUE;

			/* Receive the next packet. */
			receiveAPacket = TRUE;
		}
		else
		{
			receiveAPacket = FALSE;
		}
	}

	/* String is already sent, so free it. */
	free (strPtr);

	return (streamPtr -> streamPacketPtr);
}

/*--------------------------------------------------*/
/* Copy the contents of streamPacketPtr into the socket_
	packet_ptr pointed to by socketId. */

void
CopyStreamPacket (socketId, streamPacketPtr)
int socketId;
streamPacketPtrType streamPacketPtr;

{
	streamPacketPtrType toStreamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;
	int i;

	toStreamPacketPtr -> cmd = streamPacketPtr -> cmd;

	/* Free up the old array elements. */
	FreeStrArray (toStreamPacketPtr -> argv, toStreamPacketPtr ->
		argc);
	toStreamPacketPtr -> argv = (char **) NULL;

	toStreamPacketPtr -> argc = streamPacketPtr -> argc;

	if (toStreamPacketPtr -> argc)
	{
		toStreamPacketPtr -> argv = IniStrArray (
			toStreamPacketPtr -> argc);

		for (i = 0; i < toStreamPacketPtr -> argc; i++)
			toStreamPacketPtr -> argv [i] = strdup (streamPacketPtr ->
				argv [i]);

	}
}


/*--------------------------------------------------*/
/* Enter the command field into streamPacketPtr. */ 

streamPacketPtrType
BuildSocketPacketCommand (socketId, cmd)
int socketId;
unsigned int cmd;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;

	streamPacketPtr -> cmd = cmd;

	/* Free up the old array elements. */
	FreeStrArray (streamPacketPtr -> argv, streamPacketPtr -> argc);
	streamPacketPtr -> argv = (char **) NULL;

	streamPacketPtr -> argc = (cmd & burstSizeMsk) >> burstSizeShift;

	/* Initialize new string array. */
	if (streamPacketPtr -> argc)
		streamPacketPtr -> argv = IniStrArray (streamPacketPtr ->
			argc);

	return (streamPacketPtr);
}

/*--------------------------------------------------*/
/* Enter integerValue into the streamPacketPtr argument list
	at location offset. */ 

streamPacketPtrType
BuildSocketPacketInteger (socketId, offset, integerValue)
int socketId;
unsigned int offset, integerValue;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;
	char buf [BUFSIZ];

	if (offset >= streamPacketPtr -> argc)
		fprintf (stderr, "%s:  socket packet argument offset %d >= argc %d.\n",
			ExtractProgramName (socketId), offset, streamPacketPtr -> argc);
	else
	{
		/* Convert integer into a string for the argument list. */
		sprintf (buf, "0x%x", integerValue);

		streamPacketPtr -> argv [offset] = strdup (buf);
	}
		
	return (streamPacketPtr);
}

/*--------------------------------------------------*/
/* Enter stringValue into the streamPacketPtr argument list
	at location offset. */ 

streamPacketPtrType
BuildSocketPacketString (socketId, offset, stringValue)
int socketId;
unsigned int offset;
char *stringValue;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;

	if (offset >= streamPacketPtr -> argc)
		fprintf (stderr, "%s:  socket packet argument offset %d >= argc %d.\n",
			ExtractProgramName (socketId), offset, streamPacketPtr -> argc);
	else
		streamPacketPtr -> argv [offset] = strdup (stringValue);

	return (streamPacketPtr);
} 

/*--------------------------------------------------*/
/* Grab command part of streamPacketPtr. */

unsigned int
ExtractSocketPacketCommand (socketId)
int socketId;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;

	return (streamPacketPtr -> cmd);
}

/*--------------------------------------------------*/
/* Grab integerValue from argument list at location offset. */ 

unsigned int
ExtractSocketPacketInteger (socketId, offset)
int socketId;
unsigned int offset;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;
	unsigned int integerValue = 0;

	if (offset >= streamPacketPtr -> argc)
		fprintf (stderr, "%s:  socket packet argument offset %d >= argc %d.\n",
			ExtractProgramName (socketId), offset, streamPacketPtr -> argc);
                      /* XXX What is the return value for this case? */
	else
		integerValue = strtol (StripBeginWhiteSpace (streamPacketPtr ->
			argv [offset]), (char **) NULL, 16);

	return (integerValue);
}

/*--------------------------------------------------*/
/* Grab stringValue part of streamPacketPtr. */ 

char *
ExtractSocketPacketString (socketId, offset)
int socketId;

{
	streamPacketPtrType streamPacketPtr = gblStreamArrayPtr [socketId] ->
		streamPacketPtr;
	char *stringValue = (char *) NULL;

	if (offset >= streamPacketPtr -> argc)
		fprintf (stderr, "%s:  socket packet argument offset %d >= argc %d.\n",
			ExtractProgramName (socketId), offset, streamPacketPtr -> argc);
	else
		stringValue = streamPacketPtr -> argv [offset];

	return (stringValue);
} 

/*--------------------------------------------------*/
/* Get the socket name from the argument list. */
//This has been commented out since the NVUseArg function defined in dispatch.c is a dummy one.
//extern void NVUseArg(int num);

char *
ExtractTstSocket (argc, argv)
int argc;
char *argv [];

{
	int i;
	char str [BUFSIZ];
	char *argPtr = (char *) NULL;

	sprintf (str, "-%s", SOCKET_MINUS_ARG);

	/* Search the arguments. */
	for (i = 1; i < argc; i++)
	{
		/* Find an argument match. */
		if (! strcmp (str, argv [i])) {
            //NVUseArg(i);
			/* Get the next argument. */
			if (++i < argc) {
				argPtr = argv [i];
                //NVUseArg(i);
            }
        }
	}

	if (argPtr == (char *) NULL)
	{
		fprintf (stderr, "%s:  \"-%s tstSocket\" not found.\n",
			LastPathEle (argv [0]), SOCKET_MINUS_ARG);
		fflush (stderr);
		exit (1);
	}

	return (argPtr);
}

/*--------------------------------------------------*/
/* Set the program name associated with a particular socketId. */

void
SetProgramName (socketId, str)
char *str;

{
	if (gblStreamArrayPtr [socketId] == (streamPtrType) NULL)
	{
		fprintf (stderr, "Error:  %s:  gblStreamArrayPtr [%d] is NULL\n",
			str, socketId);
		exit (1);
	}

	/* If a name already exists, free up the memory associated with
		it. */
	if (gblStreamArrayPtr [socketId] -> progName != (char *) NULL)
	{
		free (gblStreamArrayPtr [socketId] -> progName);
	}

	gblStreamArrayPtr [socketId] -> progName = strdup (str);
}

/*--------------------------------------------------*/
/* Return the name of the program associated with a particular
	socketId. */

char *
ExtractProgramName (socketId)
int socketId;

{
	return (gblStreamArrayPtr [socketId] -> progName);
}

/*--------------------------------------------------*/
/* Return the error count associated with a particular
	socketId. */

int
ExtractErrCnt (socketId)
int socketId;

{
	return (gblStreamArrayPtr [socketId] -> errCnt);
}

/*--------------------------------------------------*/
/* Increment the error count associated with a particular
	socketId by 1. */

void
IncErrCnt (socketId)
int socketId;

{
	(gblStreamArrayPtr [socketId] -> errCnt)++;
}


/*--------------------------------------------------*/
/* Delete stream information. 
	Deallocates any structure memory.  Sets the array ptr
	to null. */

void
CloseSocket (socketId)
int socketId;

{
	/* Remove client connection. */
	clnt_destroy (gblStreamArrayPtr [socketId] -> client);

	FreeStreamArrayPtrEle (socketId);

	/* Nullify gblStreamArrayPtr. */
	gblStreamArrayPtr [socketId] = (streamPtrType) NULL;
}

/*--------------------------------------------------*/
/* Convert a stream string into a packet structure. */

streamPacketPtrType 
ConvertStr2Packet (progName, strPtr)
char *progName, *strPtr;

{
	streamPacketPtrType streamPacketPtr;
	char *tmpStrPtr, *tmp2StrPtr, *tokStrPtr, etxStr [2];
	char *strTokState;
	int idx = 0;

	streamPacketPtr = IniStreamPacketPtr (progName);

	/* End of text. */
	etxStr [0] = etxToken;
	etxStr [1] = '\0';

	/* Make a copy strPtr.  Don't destroy it. */
	tmpStrPtr = strdup (strPtr);
	tmp2StrPtr = tmpStrPtr;

	/* Break up string into seperation tokens. */
	while ((tokStrPtr = strtok_r (tmpStrPtr, etxStr, &strTokState)) != (char *) NULL)
	{
		/* Set to null for next time around through strtok_r. */
		tmpStrPtr = (char *) NULL;

/*
printf ("%d tokStrPtr=(%s) len=%d\n", idx, tokStrPtr, strlen (tokStrPtr));
fflush (stdout);
*/

		/* Get the command. */
		if (! idx)
		{
			streamPacketPtr -> cmd = strtol (tokStrPtr, (char **) NULL, 16);

			/* Get the burst count. */
			streamPacketPtr -> argc = (streamPacketPtr -> cmd &
				burstSizeMsk) >> burstSizeShift;

			/* Set up for new burst data. */
			if (streamPacketPtr -> argc)
				streamPacketPtr -> argv = IniStrArray (streamPacketPtr ->
					argc);
		}
		/* Get the string args. */
		else
		{
			if (idx > streamPacketPtr -> argc)
			{
				fprintf (stderr,
					"Error:  %s:  Num arg in stream string > burstSize=%d\n",
					progName, streamPacketPtr -> argc);
				exit (1);
			}
			else
			{
				streamPacketPtr -> argv [idx - 1] = strdup (tokStrPtr);
			}
		}

		idx++;
	}

	/* Remove strdup string. */
	free (tmp2StrPtr);

	return (streamPacketPtr);
}

/*--------------------------------------------------*/
/* Convert a packet structure into a stream string. */

char *
ConvertPacket2Str (streamPacketPtr)
streamPacketPtrType streamPacketPtr;

{
	char *strPtr, etxStr [2];
	int idx = 0, len = 0;

	/* End of text. */
	etxStr [0] = etxToken;
	etxStr [1] = '\0';

	/* Calculate string length. */
	/* Add all arguments. */
	for (idx = 0; idx < streamPacketPtr -> argc; idx++)
	{
		/* Skip null strings.  Act as if they were spaces. */
		if (streamPacketPtr -> argv [idx])
			len += strlen (streamPacketPtr -> argv [idx]);
		else
			len++;
	}

	/* Add command. */
	len += strlen ("0x00000000");

	/* Add etx. */
	len += streamPacketPtr -> argc;

	/* Add null char. */
	len++;

	strPtr = IniStr (len);

	/* Save command. */
	sprintf (strPtr, "0x%08x", streamPacketPtr -> cmd);

	/* Put all the strings together. */
	for (idx = 0; idx < streamPacketPtr -> argc; idx++)
	{
		strcat (strPtr, etxStr);
		if (streamPacketPtr -> argv [idx])
			strcat (strPtr, streamPacketPtr -> argv [idx]);
		else
			strcat (strPtr, " ");
	}

	return (strPtr);
}



