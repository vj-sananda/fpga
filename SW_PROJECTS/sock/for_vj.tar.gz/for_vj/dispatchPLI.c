#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include <string.h>
#include <sys/un.h>
#include <stdarg.h>
#include "acc_user.h"

#ifdef VCS
#	include "vcsuser.h"
/* vcsuser.h doesn't have this prototype */
extern int          tf_ipropagatep (int pnum, char *inst);
#else
#	include "veriuser.h"
#endif

#include "mystdlib.h"
#include "stdLibCore.h"
#include "dispatchPLIFtn.h"

#define	WRD_SIZE_IN_BYTES	4
#define	BYTE_SIZE_IN_BITS	8

#define printfMessage	1
#define printfErr		2

/* Hashing size of node_cell_list. */
#define NODE_CELL_LIST_SIZE	256

/* Maximum number of bits in one register or memory vector. */
#define MAX_VEC_SIZE	32

/* Tokenize value for argument types. */
#define ERROR		1
#define RWMEM		2
#define RWREG		3
#define CONST		4
#define INTEGER		5
#define REGPART		6
#define STRING		7

typedef p_tfnodeinfo TFNODEINFO_PTR;
typedef p_tfexprinfo TFEXPRINFO_PTR;
typedef s_tfnodeinfo TFNODEINFO_STRUCT;
typedef s_tfexprinfo TFEXPRINFO_STRUCT;

typedef int (*mapReadFunctionPtr_t)(char* name, int offset, int size);
typedef void (*mapWriteFunctionPtr_t)(char* name, int offset, int data, int size);

/* Contains information about a memory or register node. */
typedef struct node_cell
{
	char *node_name;
	char *instance_ptr;
	TFNODEINFO_PTR tfnodeinfo_ptr;
	TFEXPRINFO_PTR tfexprinfo_ptr;
	struct node_cell *next;
	mapReadFunctionPtr_t	readFunctionPtr;
	mapWriteFunctionPtr_t	writeFunctionPtr;
} NODE_CELL_STRUCT, *NODE_CELL_PTR;

extern TFNODEINFO_PTR init_tfnodeinfo_ptr ();
extern TFEXPRINFO_PTR init_tfexprinfo_ptr ();

/*-------------------------------------------------------*/
/* Globals. */
NODE_CELL_PTR *node_cell_list_gbl_ptr = (NODE_CELL_PTR *) NULL;
int error_cnt = 0;


/*-------------------------------------------------------*/
/* Return maximum parameter size in bits.  Used in veriuser.c. */

int SizePLI ()
{
	return (32);
}

/*-------------------------------------------------------*/
/* Initialize one node cell. */

NODE_CELL_PTR
init_node_cell_ptr ()

{
	NODE_CELL_PTR node_cell_ptr;

	if ((node_cell_ptr = (NODE_CELL_PTR) malloc (sizeof 
		(NODE_CELL_STRUCT))) == (NODE_CELL_PTR) NULL)
	{
		fprintf (stderr, "Can't allocate memory for node_cell_ptr.\n");
		exit (1);
	}

	node_cell_ptr -> node_name = (char *) NULL;
	node_cell_ptr -> instance_ptr = (char *) NULL;
	node_cell_ptr -> tfnodeinfo_ptr = init_tfnodeinfo_ptr ();
	node_cell_ptr -> tfexprinfo_ptr = init_tfexprinfo_ptr ();
	node_cell_ptr -> next = (NODE_CELL_PTR) NULL;
	node_cell_ptr -> readFunctionPtr = NULL;
	node_cell_ptr -> writeFunctionPtr = NULL;

	return (node_cell_ptr);
}

/*-------------------------------------------------------*/
/* Free up node_cell_ptr. */

void
free_node_cell_ptr (node_cell_ptr)
NODE_CELL_PTR node_cell_ptr;

{
	free (node_cell_ptr -> tfexprinfo_ptr);
	free (node_cell_ptr -> tfnodeinfo_ptr);
	free (node_cell_ptr);
}

/*-------------------------------------------------------*/
/* Initialize node cell list. */

NODE_CELL_PTR *
init_node_cell_list_ptr (size)
int size;

{
	NODE_CELL_PTR *node_cell_list_ptr;
	int i;

	if ((node_cell_list_ptr = (NODE_CELL_PTR *) malloc (sizeof 
		(NODE_CELL_PTR) * size)) == (NODE_CELL_PTR *) NULL)
	{
		fprintf (stderr, "Can't allocate memory for node_cell_list_ptr.\n");
		exit (1);
	}

	for (i = 0; i < size; i++)
		node_cell_list_ptr [i] = (NODE_CELL_PTR) NULL;

	return (node_cell_list_ptr);
}

/*-------------------------------------------------------*/
/* Initialize tfexprinfo_ptr. */

TFEXPRINFO_PTR
init_tfexprinfo_ptr ()

{
	TFEXPRINFO_PTR tfexprinfo_ptr;

	if ((tfexprinfo_ptr = (TFEXPRINFO_PTR) malloc (sizeof 
		(TFEXPRINFO_STRUCT))) == (TFEXPRINFO_PTR) NULL)
	{
		fprintf (stderr, "Can't allocate memory for tfexprinfo_ptr.\n");
		exit (1);
	}

	return (tfexprinfo_ptr);
}

/*-------------------------------------------------------*/
/* Initialize tfnodeinfo_ptr. */

TFNODEINFO_PTR
init_tfnodeinfo_ptr ()

{
	TFNODEINFO_PTR tfnodeinfo_ptr;

	if ((tfnodeinfo_ptr = (TFNODEINFO_PTR) malloc (sizeof 
		(TFNODEINFO_STRUCT))) == (TFNODEINFO_PTR) NULL)
	{
		fprintf (stderr, "Can't allocate memory for tfnodeinfo_ptr.\n");
		exit (1);
	}

	return (tfnodeinfo_ptr);
}

/*-------------------------------------------------------*/
/* Generate an integer value from a character string. */

int
hash_value (name)
char *name;

{
	int value = 0;

	while (*name != '\0')
		value += *name++ & 0xff;

	return (value);
}

/*-------------------------------------------------------*/
/* Save a node cell in the node_cell_list hash table. */
/* Return TRUE if successful, FALSE otherwise. */

/* 2003-04-22 DaveW: rewriten to allow duplicates in list */

int
save_node_cell (new_cell)
NODE_CELL_PTR new_cell;

{
    NODE_CELL_PTR iter, *where;

    int list_index = hash_value(new_cell -> node_name) % NODE_CELL_LIST_SIZE;

    /* If the list ptr is null, create the list. */
    if (!node_cell_list_gbl_ptr)
    {
	node_cell_list_gbl_ptr = init_node_cell_list_ptr(NODE_CELL_LIST_SIZE);
    }

    /* Go to node_cell indexed by list_index. */ 
    where = &node_cell_list_gbl_ptr[list_index];
    iter = *where;

    /* iterate though sorted list */
    while (iter && (strcmp(iter->node_name, new_cell->node_name) < 0))
    {
	where = &(iter->next);
	iter = *where;
    }

    /* insert cell into list */
    new_cell->next = iter;
    *where = new_cell;

    return TRUE;
}


/*-------------------------------------------------------*/
/* Classify argument. */

int
token_arg (arg_num)
int arg_num;

{
	TFNODEINFO_PTR tfnodeinfo_ptr = init_tfnodeinfo_ptr ();
	TFEXPRINFO_PTR tfexprinfo_ptr = init_tfexprinfo_ptr ();
	int token = ERROR;

	if (tf_nodeinfo (arg_num, tfnodeinfo_ptr) &&
		tf_exprinfo (arg_num, tfexprinfo_ptr))
	{
		/* r/w memory node. */
		if ((tfnodeinfo_ptr -> node_type == tf_memory_node) &&
			(tfexprinfo_ptr -> expr_type == tf_rwmemselect)) 
			token = RWMEM;
		/* r/w register node. */
		else if ((tfnodeinfo_ptr -> node_type == tf_reg_node) &&
			(tfexprinfo_ptr -> expr_type == tf_readwrite))
			token = RWREG;
#		ifdef VCS
		/* r/ const node. */
		else if ((tfnodeinfo_ptr -> node_type == tf_netscalar_node) &&
			(tfexprinfo_ptr -> expr_type == tf_readonly))
			token = CONST;
		else if ((tfnodeinfo_ptr -> node_type == tf_netvector_node) &&
			(tfexprinfo_ptr -> expr_type == tf_readonly))
			token = CONST;
#		else
		/* r/ const node. */
		else if ((tfnodeinfo_ptr -> node_type == tf_null_node) &&
			(tfexprinfo_ptr -> expr_type == tf_readonly))
			token = CONST;
#		endif
		/* r/w integer. */
		else if ((tfnodeinfo_ptr -> node_type == tf_integer_node) &&
			(tfexprinfo_ptr -> expr_type == tf_readwrite))
			token = INTEGER;
		/* r/w register part. */
		else if ((tfnodeinfo_ptr -> node_type == tf_reg_node) &&
			(tfexprinfo_ptr -> expr_type == tf_rwpartselect))
			token = REGPART;
#		ifdef VCS
		/* string node. */
		else if (( (tfnodeinfo_ptr -> node_type == tf_netvector_node) ||
		           (tfnodeinfo_ptr -> node_type == tf_null_node) ) &&
			(tfexprinfo_ptr -> expr_type == tf_string))
			token = STRING;
#		else
		/* string node. */
		else if ((tfnodeinfo_ptr -> node_type == tf_null_node) &&
			(tfexprinfo_ptr -> expr_type == tf_string))
			token = STRING;
#		endif
		else
			io_printf ("node_type = %d : expr_type = %d\n",
				tfnodeinfo_ptr -> node_type, tfexprinfo_ptr -> expr_type);		

	}

	free (tfnodeinfo_ptr);
	free (tfexprinfo_ptr);

	return (token);
}

/*-------------------------------------------------------*/
// Look in data base for a mapFunc node with node_name.
// If found, return a ptr to the node_cell.

NODE_CELL_PTR 
find_func_node_cell_ptr(
	char *node_name
)
{
	NODE_CELL_PTR pres_node_cell_ptr = 0;

	// Look for function call node pointers

	if (node_cell_list_gbl_ptr != (NODE_CELL_PTR *) NULL) {
		int		j;
		// Have to search all lists since name match is a wildcard

		for (j = 0; j < NODE_CELL_LIST_SIZE; j++) {
			for (pres_node_cell_ptr = node_cell_list_gbl_ptr[j];
				pres_node_cell_ptr != (NODE_CELL_PTR) NULL;
				pres_node_cell_ptr = pres_node_cell_ptr->next) {
				if ((pres_node_cell_ptr->readFunctionPtr != NULL) ||
					(pres_node_cell_ptr->writeFunctionPtr != NULL)) {
					// Check for wildcard match against function call nodes

					int	len = strlen(pres_node_cell_ptr->node_name);
					if (strncmp(pres_node_cell_ptr->node_name, node_name, len) == 0)
						return (pres_node_cell_ptr);
				}
			}
		}
	}

	return ((NODE_CELL_PTR) NULL);
}

/*-------------------------------------------------------*/
/* Look in data base for node_name.  If found, return a
	ptr to the node_cell. */

NODE_CELL_PTR 
find_node_cell_ptr (node_name)
char *node_name;

{
	NODE_CELL_PTR pres_node_cell_ptr = 0;
	int list_index = (hash_value (node_name)) % NODE_CELL_LIST_SIZE;
	int found = FALSE;

	/* Make sure a global list exists. */
	if (node_cell_list_gbl_ptr)
	{
		pres_node_cell_ptr = node_cell_list_gbl_ptr [list_index];

		/* Quit if current node_cell is null. */
		while (pres_node_cell_ptr && ! found)
			/* Match on node_name. */
			if (!strcmp (pres_node_cell_ptr -> node_name, node_name))
				found = TRUE;
			else
				pres_node_cell_ptr = pres_node_cell_ptr -> next;
	}

	// Look for function call node pointers
	if (!found)
		return find_func_node_cell_ptr(node_name);

	return (pres_node_cell_ptr);
}

/*-------------------------------------------------------*/
/* Get a byte, half word, or word from memory.  Memory is
	assumed to be little endian. */
/* Memory structure:
	reg [n:0] mem [m:0] transforms to
	tfnodeinfo_ptr -> node_value.memoryval_p -> (char *)
		avalue0,0 ... avalue0,n/BYTE_SIZE_IN_BITS
		bvalue0,0 ... bvalue0,n/BYTE_SIZE_IN_BITS ...
		avaluem,0 ... avaluem,n/BYTE_SIZE_IN_BITS
		bvaluem,0 ... bvaluem,n/BYTE_SIZE_IN_BITS
		
	Example:
	reg [15:0] mem [1:0] tranforms to
			a0,0 a0,1 b0,0 b0,1 a1,0 a1,1 b1,0 b1,1
	mem_bit 0-7  0-7            0-7  0-7
	mem_col 0    1              0    1
    mem_row 0                   4 */

unsigned int
get_mem_value (tfnodeinfo_ptr, offset, type)
TFNODEINFO_PTR tfnodeinfo_ptr;
unsigned int offset;
int type;

{
	unsigned int mem_size, value = 0;
	unsigned int avalue = 0, bvalue = 0;
	unsigned int mem_col, mem_row, mem_bit;
	unsigned int col, row;
	unsigned int bit_offset;
	int i;

	/* How many bits in memory. */
	mem_size = tfnodeinfo_ptr -> node_vec_size * tfnodeinfo_ptr ->
		node_mem_size;
	/* How many bytes in memory. */
	mem_size = (mem_size + (BYTE_SIZE_IN_BITS - 1)) / BYTE_SIZE_IN_BITS;
	
	/* Memory offset must be within the memory size. */ 
	if (offset < mem_size)
	{
		/* Assuming memory is a continuation of bits, find starting
			bit_offset. */
		bit_offset = offset * BYTE_SIZE_IN_BITS;
		for (i = 0; i < (type * BYTE_SIZE_IN_BITS); i++)
		{
			/* Col marks bit offset in row.  Each row is node_vec_size
				bits in length. */
			col = (bit_offset + i) % tfnodeinfo_ptr -> node_vec_size;
			row = (bit_offset + i) / tfnodeinfo_ptr -> node_vec_size;

			/* Memory positions are in bytes. */
			/* The 2 takes in account the b part of each value. */
			mem_row = row * (tfnodeinfo_ptr -> node_ngroups * 2);
			mem_col = col / BYTE_SIZE_IN_BITS;

			/* Bit position within mem_col element. */
			mem_bit = col % BYTE_SIZE_IN_BITS;

			/* Get avalue. */
			if (tfnodeinfo_ptr -> node_value.memoryval_p [mem_row +
				mem_col] & (1 << mem_bit))
				avalue += (1 << i);

			/* bvalue exists at an offset of node_ngroups from avalue. */
			if (tfnodeinfo_ptr -> node_value.memoryval_p [mem_row +
				mem_col + tfnodeinfo_ptr -> node_ngroups] &
				(1 << mem_bit))
				bvalue += (1 << i);
		}
		/* Zero out bits in value that have bits set in bvalue. */
		value = avalue & ~bvalue;

	}
	else
		tf_message (ERR_ERROR, "$DirectRdPLI", "MEM REG",
			"Accessing memory element outside memory region.");

	return (value);
}

/*-------------------------------------------------------*/
/* utility function: convert address to node_name */

static const char *int_to_node_name( int address )
{
    static char buffer[32];
    sprintf(buffer, "address:0x%08x", address);
    return buffer;
}

/*-------------------------------------------------------*/
/* utility function: get node_name from tf arg */

static const char *get_node_name_from_arg( unsigned argnum, const char *reason )
{
    switch (token_arg (argnum))
    {
	case STRING:
	    return tf_getcstringp (argnum);

	case RWMEM:
	case RWREG:
	case CONST:
	case INTEGER:
	case REGPART:
	    return int_to_node_name(tf_getp(argnum));

	default:	
	    tf_message (ERR_ERROR, (char*)reason, "BAD ARG",
		    "Argument %d must be a string.", argnum);
	    break;
    }

    return NULL;
}


/*-------------------------------------------------------*/
/* Put a byte, half word, or word into memory.  Memory is
	assumed to be little endian. */

void
put_mem_value (tfnodeinfo_ptr, offset, type, data)
TFNODEINFO_PTR tfnodeinfo_ptr;
unsigned int offset, data;
int type;

{
	unsigned int mem_size;
	unsigned int mem_col, mem_row, mem_bit;
	unsigned int col, row;
	unsigned int bit_offset;
	int i;

	/* How many bits in memory. */
	mem_size = tfnodeinfo_ptr -> node_vec_size * tfnodeinfo_ptr ->
		node_mem_size;
	/* How many bytes in memory. */
	mem_size = (mem_size + (BYTE_SIZE_IN_BITS - 1)) / BYTE_SIZE_IN_BITS;
	
	/* Memory offset must be within the memory size. */ 
	if (offset < mem_size)
	{
		/* Assuming memory is a continuation of bits, find starting
			bit_offset. */
		bit_offset = offset * BYTE_SIZE_IN_BITS;
		for (i = 0; i < (type * BYTE_SIZE_IN_BITS); i++)
		{
			/* Col marks bit offset in row.  Each row is node_vec_size
				bits in length. */
			col = (bit_offset + i) % tfnodeinfo_ptr -> node_vec_size;
			row = (bit_offset + i) / tfnodeinfo_ptr -> node_vec_size;

			/* Memory positions are in bytes. */
			/* The 2 takes in account the b part of each value. */
			mem_row = row * (tfnodeinfo_ptr -> node_ngroups * 2);
			mem_col = col / BYTE_SIZE_IN_BITS;

			/* Bit position within mem_col element. */
			mem_bit = col % BYTE_SIZE_IN_BITS;

			/* Put avalue. */
			if (data & (1 << i))
				/* Set bit. */
				tfnodeinfo_ptr -> node_value.memoryval_p [mem_row +
					mem_col] |= (1 << mem_bit);
			else
				/* Reset bit. */
				tfnodeinfo_ptr -> node_value.memoryval_p [mem_row +
					mem_col] &= ~(1 << mem_bit);
			

			/* bvalue exists at an offset of node_ngroups from avalue. */
			/* Clear each bvalue bit. */
			tfnodeinfo_ptr -> node_value.memoryval_p [mem_row +
				mem_col + tfnodeinfo_ptr -> node_ngroups] &=
 				~(1 << mem_bit);
		}

	}
	else
		tf_message (ERR_ERROR, "$DirectWrtPLI", "MEM REG",
			"Accessing memory element outside memory region.");
}

/*-------------------------------------------------------*/
/* Read register or memory value and return value. */

unsigned int
direct_read (node_name, offset, type)
char *node_name;
unsigned int offset;
int type;

{
	NODE_CELL_PTR node_cell_ptr;
	unsigned int value = 0;

	/* Get a ptr to the node_cell that matches the node_name. */ 
	node_cell_ptr = find_node_cell_ptr (node_name);

	/* If node_cell_ptr was found. */
	if (node_cell_ptr != (NODE_CELL_PTR) NULL)
	{
		/* Re-evaluate node argument associated with a previous
			$Map command.  (Node argument is argument 1 of $Map
			function.) */
		tf_ievaluatep (1, node_cell_ptr -> instance_ptr);

		/* It's a register. */
		if ((node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_reg_node) ||
                    (node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_netscalar_node) ||
                    (node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_netvector_node))
		{
			value = node_cell_ptr -> tfexprinfo_ptr -> expr_value_p ->
				avalbits;
			value &= ~(node_cell_ptr -> tfexprinfo_ptr -> expr_value_p ->
				bvalbits);
		} else
		/* It's a memory. */
		if (node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_memory_node)
		{
			value = get_mem_value (node_cell_ptr -> tfnodeinfo_ptr, offset,
				type);
		} else
		/* It's a function call. */
		if (node_cell_ptr->readFunctionPtr != NULL) {
			int	size = 4;
			if (type == byte1) size = 1;
			else if (type == halfWrd) size = 2;
			else if (type == wrd) size = 4;

			value = (*node_cell_ptr->readFunctionPtr)(node_name, offset, size);
		} else {
                  tf_message (ERR_ERROR, "$DirectRdPLI", "UNK TYPE",
                              "don't know how to read \"%s\"!", node_name);
                }
	}
	else
		tf_message (ERR_ERROR, "$DirectRdPLI", "UNK NAME",
			"\"%s\" is not mapped!", node_name);

	return (value);
}

/*-------------------------------------------------------*/
/* Write register or memory value. */
/* 2003-04-22 DaveW: write all duplicates in node_cell-list: */

void
direct_write (node_name, offset, type, data)
char *node_name;
unsigned int offset, data;
int type;

{
    NODE_CELL_PTR node_cell_ptr;

    node_cell_ptr = find_node_cell_ptr(node_name);

    if (!node_cell_ptr)
    {
	tf_message (ERR_ERROR, "$DirectWrtPLI", "UNK NAME",
		"\"%s\" is not mapped!", node_name);
    }
    else while ( node_cell_ptr && strcmp(node_cell_ptr->node_name, node_name) == 0 )
    {
	unsigned int reg_mask;

	/* It's a register. */
	if (node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_reg_node)
	{
	    /* Only save valid data bits. */
	    if (node_cell_ptr -> tfexprinfo_ptr -> expr_vec_size >= 32)
		reg_mask = 0xffffffff;
	    else
		reg_mask = (1 << node_cell_ptr -> tfexprinfo_ptr ->
			expr_vec_size) - 1;

	    node_cell_ptr -> tfexprinfo_ptr -> expr_value_p -> avalbits =
		data & reg_mask;

	    /* Load zeroes in approriate bit positions of bvalue. */
	    node_cell_ptr -> tfexprinfo_ptr -> expr_value_p -> bvalbits =
		~reg_mask;

	    /* Propagate node argument associated with a previous
	       $Map command.  (Node argument is argument 1 of $Map
	       function.) */
	    tf_ipropagatep (1, node_cell_ptr -> instance_ptr);
	}
	/* It's a memory. */
	else if (node_cell_ptr -> tfnodeinfo_ptr -> node_type == tf_memory_node)
	{
	    put_mem_value (node_cell_ptr -> tfnodeinfo_ptr, offset,
		    type, data);
	}
	/* It's a function call. */
	else if (node_cell_ptr->writeFunctionPtr != NULL) {
	    int	size = 4;
	    if (type == byte1) size = 1;
	    else if (type == halfWrd) size = 2;
	    else if (type == wrd) size = 4;

	    (*node_cell_ptr->writeFunctionPtr)(node_name, offset, data, size);
	}
	/* otherwise its not writeable */
	else
	{
	    tf_message (ERR_ERROR, "$DirectWrtPLI", "UNK NAME",
		    "\"%s\" is not writeable!", node_name);
	}

	node_cell_ptr = node_cell_ptr->next;
    }
}

/*-------------------------------------------------------*/
/* Handle direct reads into verilog regs and mems. */
/* $DirectRdPLI (socketId); */

int
DirectRdPLI ()

{
	unsigned int value = 0;
	int socketId;
	char *node_name;
	unsigned int offset;
	int type;

	/* Make sure one argument exists. */
	if (tf_nump () == 1)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				/* Extract type, node_name, and offset. */
				type = ExtractSocketPacketInteger (socketId, 2);
				if ((type != byte1) && (type != halfWrd) && (type != wrd))
					type = wrd;

				node_name = ExtractSocketPacketString (socketId, 0);
				
				offset = ExtractSocketPacketInteger (socketId, 1);

				/* Read the value. */
				value = direct_read (node_name, offset, type);

				/* Ack with data. */
				/*
				BuildSocketPacketCommand (socketId, ack |
					(1 << burstSizeShift));
				BuildSocketPacketInteger (socketId, 0, value);
				SendSocket (socketId);
				*/

				break;
			default:	
				tf_message (ERR_ERROR, "$DirectRdPLI", "BAD ARG",
					"Argument 1 must be an int or reg.");
				break;
		}

	}
	else
		tf_message (ERR_ERROR, "$DirectRdPLI", "ARG NUM",
			"Function requires 0 arguments");

	/* Return data. */
	tf_putp (0, value);

	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Handle direct writes into verilog regs and mems. */
/* $DirectWrtPLI (socketId); */
/* $DirectWrtPLI (name/address, value); */

int
DirectWrtPLI ()
{
    const char *node_name = NULL;
    unsigned int offset = 0;
    unsigned int data = 0;
    int error = FALSE;
    int type = 0;

    /* 2 ways to call it: 1-arg gets info direct from socket; 2 args is name=value pair. */
    if (tf_nump () == 1)
    {
        /* Get argument. */
        switch (token_arg (1))
        {
            case INTEGER:
            case RWREG:
            {
                /* Get socketId as an integer. */
                int socketId = tf_getp (1);

                /* Extract type, node_name, and offset. */
                type = ExtractSocketPacketInteger (socketId, 2);
                if ((type != byte1) && (type != halfWrd) && (type != wrd))
                    type = wrd;

                node_name = ExtractSocketPacketString (socketId, 0);

                offset = ExtractSocketPacketInteger (socketId, 1);

                data = ExtractSocketPacketInteger (socketId, 3);

                /* Ack. */
                /*
                   BuildSocketPacketCommand (socketId, ack);
                   SendSocket (socketId);
                   */

                break;
            }

            default:	
                error = TRUE;
                node_name = NULL;
                tf_message (ERR_ERROR, "$DirectWrtPLI", "BAD ARG",
                        "Argument 1 must be an int or reg.");
                break;
        }

    }
    else if (tf_nump () == 2)
    {
        node_name = get_node_name_from_arg(1, "$DirectWrtPLI");
        error = !node_name; /* error if NULL */
        data = tf_getp(2);
        type = wrd;
    }
    else
    {
        error = TRUE;
        tf_message (ERR_ERROR, "$DirectWrtPLI", "ARG NUM",
                "Function requires 0 arguments");
    }

    if (! error)
    {
        direct_write (node_name, offset, type, data);
    }

    return 0;
}

/*-------------------------------------------------------*/
/* Map a unique address to a memory region or a register. */
/* $Map (node, uniqueAdr); */

int
Map ()

{
    NODE_CELL_PTR node_cell_ptr = 0;
    int success = FALSE;
    const char *node_name = 0;
    int token;

    /* Make sure two arguments exist. */
    if (tf_nump () == 2)
    {
	/* Get second argument as a string. */
	node_name = get_node_name_from_arg(2, "$Map");
    }
    else
    {
	tf_message (ERR_ERROR, "$Map", "ARG NUM",
		"Function requires 2 arguments.");
    }

    if (node_name)
    {
	/* Generate a node cell. */
	node_cell_ptr = init_node_cell_ptr ();
	node_cell_ptr -> node_name = strsave(node_name);
	node_cell_ptr -> instance_ptr = (char *) tf_getinstance ();

	/* Tokenize argument 1. */
	token = token_arg (1);

	/* If the token is valid, link up the node and expr structures. */ 
	if ((token == RWMEM) || (token == RWREG))
	{
	    tf_nodeinfo (1, node_cell_ptr -> tfnodeinfo_ptr);
	    tf_exprinfo (1, node_cell_ptr -> tfexprinfo_ptr);

	    /* Only support registers with up to MAX_VEC_SIZE bits. */
	    if (token == RWREG)
		if (node_cell_ptr -> tfexprinfo_ptr -> expr_vec_size >
			MAX_VEC_SIZE)
		{
		    tf_message (ERR_ERROR, "$Map", "VEC SIZE",
			    "Register %s vector size %d > %d.", node_cell_ptr ->
			    tfnodeinfo_ptr -> node_symbol, node_cell_ptr -> 
			    tfexprinfo_ptr -> expr_vec_size, MAX_VEC_SIZE); 
		}
		else
		    success = save_node_cell (node_cell_ptr);
	    else
		success = save_node_cell (node_cell_ptr);
	}
	else if (token == CONST) /* hopefully a wire -- read-only */
	{
	    tf_nodeinfo (1, node_cell_ptr -> tfnodeinfo_ptr);
	    tf_exprinfo (1, node_cell_ptr -> tfexprinfo_ptr);

	    success = save_node_cell (node_cell_ptr);
	}
	else
	    tf_message (ERR_ERROR, "$Map", "BAD ARG",
		    "Arg 1 for %s must be a reg, mem or wire.", node_name);
    }

    /* If an error occured, free up malloced structures. */
    if (! success)
	free_node_cell_ptr (node_cell_ptr);
    return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Is the given name/address mapped. */
/* $IsMapped (uniqueAdr); */

int
IsMapped ()

{
    int success = FALSE;
    const char *node_name = NULL;

    /* Make sure two arguments exist. */
    if (tf_nump () == 1)
    {
	node_name = get_node_name_from_arg(1, "$IsMapped");
    }
    else
    {
	tf_message (ERR_ERROR, "$IsMapped", "ARG NUM",
		"Function requires 1 argument.");
    }

    if (node_name)
    {
	success = find_node_cell_ptr(node_name) ? 1 : 0;
    }

    tf_putp(0, success);

    return 0;
}


//-------------------------------------------------------
// Map a wildcard address to read and write function calls.
// MapFunc(
//		char*	address,
//		mapReadFunctionPtr_t	readFunc,
//		mapWriteFunctionPtr_t	writeFunc
// )

void
MapFunc(
	char*	address,
	mapReadFunctionPtr_t	readFunc,
	mapWriteFunctionPtr_t	writeFunc
)
{
	if (!find_func_node_cell_ptr(address)) {
		NODE_CELL_PTR node_cell_ptr = 0;

		// Generate a node cell.
		node_cell_ptr = init_node_cell_ptr ();
		node_cell_ptr->node_name = address;
		node_cell_ptr->instance_ptr = (char *) tf_getinstance();
		node_cell_ptr->readFunctionPtr = readFunc;
		node_cell_ptr->writeFunctionPtr = writeFunc;

		// If an error occured, free up malloced structures.
		if (!save_node_cell(node_cell_ptr))
			free_node_cell_ptr(node_cell_ptr);
	}
}

/*-------------------------------------------------------*/
/* Display the contents of the node_cell_list hash table. */
/* $DisplayModeList ();. */

int
DisplayNodeList ()

{
	NODE_CELL_PTR node_cell_ptr;
	int i;

	if (node_cell_list_gbl_ptr != (NODE_CELL_PTR *) NULL)
	{
		for (i = 0; i < NODE_CELL_LIST_SIZE; i++)
		{
			node_cell_ptr = node_cell_list_gbl_ptr [i];

			while (node_cell_ptr != (NODE_CELL_PTR) NULL)
			{
				io_printf ("element %d\n", i);
				io_printf ("node_name %s\n", node_cell_ptr -> node_name);
				io_printf ("tfnodeinfo_ptr -> node_symbol %s\n",
					node_cell_ptr -> tfnodeinfo_ptr -> node_symbol);
				io_printf ("\n");

				node_cell_ptr = node_cell_ptr -> next;
			}
		}
	}
	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Extract numStreams from Verilog + arg. */
/* numStreams = $ExtractNumStreamsPLI; */

int
ExtractNumStreamsPLI ()

{
	char *str_ptr;
	int value = 0;

	/* Make sure no argument exists. */
	if (tf_nump () == 0)
	{
		if ((str_ptr = mc_scan_plusargs (NUMSTREAMS_PLUS_ARG)) == (char *) NULL)
		{
			tf_message (ERR_ERROR, "$ExtractNumStreamsPLI", "PLUS ARG",
				"Verilog requires a +%s=[numStreams] argument",
				NUMSTREAMS_PLUS_ARG);
		}
		else
		{
			/* Skip whitespace. */
			while (isspace (*str_ptr) && *str_ptr != '\0')
				str_ptr++;
			/* Skip equal sign. */
			if (*str_ptr == '=')
			{
				str_ptr++;

				/* Skip whitespace. */
				while (isspace (*str_ptr) && *str_ptr != '\0')
					str_ptr++;

				if (! myatoi2 (str_ptr, &value))
				{
					tf_message (ERR_ERROR, "$ExtractNumStreamsPLI", "PLUS ARG",
						"[numStreams] in Verilog argument must be an integer");
				}
			}
			else
				tf_message (ERR_ERROR, "$ExtractNumStreamsPLI", "PLUS ARG",
					"Verilog requires an \"=\" in the plus argument");
		}
	}
	else
		tf_message (ERR_ERROR, "$ExtractNumStreamsPLI", "ARG NUM",
			"Function requires 0 arguments");

	/* Return socketId. */
	tf_putp (0, value);

	return 0;			/* gcc - shutup */
}

// Built-in clock

int
clockRead(
	char* name,
	int offset,
	int size
)
{
	static int	highTime;

	if (strcmp(name, "simulationClock/low") == 0)
	    return tf_getlongtime(&highTime);
	else if (strcmp(name, "simulationClock/high") == 0)
	    return highTime;
	else if (strcmp(name, "simulationClock/units") == 0) {
		s_timescale_info	info;
		acc_fetch_timescale_info(acc_handle_tfinst(), &info);
		return info.precision;
	}

	return 0;
}

/*-------------------------------------------------------*/
/* Establish connection with the socket.  The socket name
	is derivied from mc_scan_plusargs (Verilog + command
	line option).  Returns a socketId. */
/* socketId = $ConnectSocketPLI; */

int
ConnectSocketPLI ()

{
	char *socket_name;
	int socketId = 0;

	MapFunc("simulationClock", clockRead, NULL);	// Map builtin clock

	/* Make sure no argument exists. */
	if (tf_nump () == 0)
	{
		if ((socket_name = mc_scan_plusargs (SOCKET_PLUS_ARG)) == (char *) NULL)
		{
			tf_message (ERR_ERROR, "$ConnectSocketPLI", "PLUS ARG",
				"Verilog requires a +%s=[socketName] argument",
				SOCKET_PLUS_ARG);
		}

		/* Skip whitespace. */
		while (isspace (*socket_name) && *socket_name != '\0')
			socket_name++;

		/* Skip equal sign. */
		if (*socket_name == '=')
			socket_name++;
		else
			tf_message (ERR_ERROR, "$ConnectSocketPLI", "PLUS ARG",
				"Verilog requires a +%s=[socketName] argument",
				SOCKET_PLUS_ARG);

		/* Skip whitespace. */
		while (isspace (*socket_name) && *socket_name != '\0')
			socket_name++;

		/* Connect up to the socket and test connection. */
		socketId = ConnectSocket (socket_name, tf_mipname ());

	}
	else
		tf_message (ERR_ERROR, "$ConnectSocketPLI", "ARG NUM",
			"Function requires 0 arguments");

	/* Return socketId. */
	tf_putp (0, socketId);

	return 0;			/* gcc - shutup */
} 

/*-------------------------------------------------------*/
/* Receive a socket packet. */
/* $ReceiveSocketPLI (socketId); */

int
ReceiveSocketPLI ()

{
	int socketId;

	/* Make sure one argument exists. */
	if (tf_nump () == 1)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				/* Wait until a packet is received. */
				ReceiveSocket (socketId);

				break;
			default:	
				tf_message (ERR_ERROR, "$ReceiveSocketPLI", "BAD ARG",
					"Argument 1 must be an int or reg.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$ReceiveSocketPLI", "ARG NUM",
			"Function allows 1 argument.");
	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Send a socket packet. */
/* $SendSocketPLI (socketId); */

int
SendSocketPLI ()

{
	int socketId;

	/* Make sure one argument exists. */
	if (tf_nump () == 1)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				/* Wait until a packet is received. */
				SendSocket (socketId);

				break;
			default:	
				tf_message (ERR_ERROR, "$SendSocketPLI", "BAD ARG",
					"Argument 1 must be an int or reg.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$SendSocketPLI", "ARG NUM",
			"Function allows 1 argument.");
	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Extract command field from socket packet. */
/* command = $ExtractSocketPacketCommandPLI (socketId); */


int
ExtractSocketPacketCommandPLI ()

{
	int socketId;
	unsigned int command = 0;

	/* Make sure one argument exists. */
	if (tf_nump () == 1)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				/* Extract command. */
				command = ExtractSocketPacketCommand (socketId);

				break;
			default:	
				tf_message (ERR_ERROR, "$ExtractSocketPacketCommandPLI",
					"BAD ARG", "Argument 1 must be an int or reg.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$ExtractSocketPacketCommandPLI", "ARG NUM",
			"Function allows 1 argument.");

	/* Return command. */
	tf_putp (0, command);

	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Extract integer field from socket packet. */
/* integerValue = $ExtractSocketPacketIntegerPLI (socketId, off); */


int
ExtractSocketPacketIntegerPLI ()

{
	int socketId = 0;
	unsigned int integerValue = 0, off;

	/* Make sure two argument exists. */
	if (tf_nump () == 2)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				break;
			default:	
				tf_message (ERR_ERROR, "$ExtractSocketPacketIntegerPLI",
					"BAD ARG", "Argument 1 must be an int or reg.");
				break;
		}

		/* Get offset. */
		switch (token_arg (2))
		{
			case INTEGER:
			case RWREG:
			case CONST:
				off = tf_getp (2);

				integerValue = ExtractSocketPacketInteger (socketId, off);
				break;
			default:	
				tf_message (ERR_ERROR, "$ExtractSocketPacketIntegerPLI",
					"BAD ARG", "Argument 2 must be an int, reg, const.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$ExtractSocketPacketIntegerPLI", "ARG NUM",
			"Function allows 2 arguments.");

	/* Return integer. */
	tf_putp (0, integerValue);

	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Construct socket packet command field. */
/* $BuildSocketPacketCommandPLI (socketId, command); */


int
BuildSocketPacketCommandPLI ()

{
	int socketId = 0;
	unsigned int command;

	/* Make sure one argument exists. */
	if (tf_nump () == 2)
	{
		/* Get socketId. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);
				break;
			default:	
				tf_message (ERR_ERROR, "$BuildSocketPacketCommandPLI",
					"BAD ARG", "Argument 1 must be an int or reg.");
				break;
		}

		/* Get command. */
		switch (token_arg (2))
		{
			case INTEGER:
			case RWREG:
			case CONST:
				/* Get socketId as an integer. */
				command = tf_getp (2);

				/* Build approriate socket packet. */
				BuildSocketPacketCommand (socketId, command);

				break;
			default:	
				tf_message (ERR_ERROR, "$BuildSocketPacketCommandPLI",
					"BAD ARG", "Argument 2 must be an int, reg, or const.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$BuildSocketPacketCommandPLI", "ARG NUM",
			"Function allows 2 arguments.");
	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Construct socket integer fields. */
/* $BuildSocketPacketIntegerPLI (socketId, offset, integerValue); */


int
BuildSocketPacketIntegerPLI ()

{
	int socketId = 0;
	unsigned int integerValue, off = 0;

	/* Make sure three arguments exists. */
	if (tf_nump () == 3)
	{
		/* Get socketId. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);
				break;
			default:	
				tf_message (ERR_ERROR, "$BuildSocketPacketIntegerPLI",
					"BAD ARG", "Argument 1 must be an int or reg.");
				break;
		}

		/* Get offset. */
		switch (token_arg (2))
		{
			case INTEGER:
			case RWREG:
			case CONST:
				/* Get socketId as an integer. */
				off = tf_getp (2);
				break;
			default:	
				tf_message (ERR_ERROR, "$BuildSocketPacketIntegerPLI",
					"BAD ARG", "Argument 2 must be an int, reg, or const.");
				break;
		}

		/* Get integerValue. */
		switch (token_arg (3))
		{
			case INTEGER:
			case RWREG:
			case CONST:
				/* Get socketId as an integer. */
				integerValue = tf_getp (3);

				/* Build approriate socket packet. */
				BuildSocketPacketInteger (socketId, off, integerValue);

				break;
			default:	
				tf_message (ERR_ERROR, "$BuildSocketPacketIntegerPLI",
					"BAD ARG", "Argument 3 must be an int, reg, or const.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$BuildSocketPacketIntegerPLI", "ARG NUM",
			"Function allows 3 arguments.");
	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Display socket packet string. */
/* $DisplaySocketPacketStringPLI (socketId, off); */

int
DisplaySocketPacketStringPLI ()

{
	int socketId = 0;
	unsigned int off;
	char *str_ptr, *new_str_ptr, buf [STR_LENGTH];

	/* Make sure one argument exists. */
	if (tf_nump () == 2)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);
				break;
			default:	
				tf_message (ERR_ERROR, "$DisplaySocketPacketStringPLI",
					"BAD ARG", "Argument 1 must be an int or reg.");
				break;
		}

		/* Get offset. */
		switch (token_arg (2))
		{
			case INTEGER:
			case RWREG:
			case CONST:
				/* Get offset as an integer. */
				off = tf_getp (2);

				str_ptr = ExtractSocketPacketString (socketId, off);
                                
                                new_str_ptr = (char *) malloc (strlen(str_ptr) + 1);
                                strcpy (new_str_ptr, str_ptr);
                                
				/* For all time substitutions, substitute. */
				sprintf (buf, "%d", tf_gettime ());
				new_str_ptr = strsub("%t", buf, new_str_ptr);

				/* For all newline substitutions, substitute. */
				sprintf (buf, "\n");
				new_str_ptr = strsub("\\n", buf, new_str_ptr);

				/* Print string. */
				io_printf (new_str_ptr);
				io_printf ("\n");
				
				free (new_str_ptr);

				/* Ack. */
				/*
				BuildSocketPacketCommand (socketId, ack);
				SendSocket (socketId);
				*/

				break;
			default:	
				tf_message (ERR_ERROR, "$DisplaySocketPacketStringPLI",
					"BAD ARG", "Argument 2 must be an int, reg, or const.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$DisplaySocketPacketStringPLI", "ARG NUM",
			"Function allows 2 arguments.");

	return 0;			/* gcc - shutup */
}

/*-------------------------------------------------------*/
/* Close socket. */
/* $CloseSocketPLI (socketId); */

int
CloseSocketPLI ()

{
	int socketId;

	/* Make sure one argument exists. */
	if (tf_nump () == 1)
	{
		/* Get argument. */
		switch (token_arg (1))
		{
			case INTEGER:
			case RWREG:
				/* Get socketId as an integer. */
				socketId = tf_getp (1);

				/* Ack. */
				BuildSocketPacketCommand (socketId, ack);
				SendSocket (socketId);

				CloseSocket (socketId);
				
				break;
			default:	
				tf_message (ERR_ERROR, "$CloseSocketPLI", "BAD ARG",
					"Argument 1 must be an int or reg.");
				break;
		}
	}
	else
		tf_message (ERR_ERROR, "$CloseSocketPLI", "ARG NUM",
			"Function allows 1 argument.");

	return 0;			/* gcc - shutup */
}
