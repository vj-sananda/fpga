/* Non blocking interface header file. */

#if ! defined (ACC_VER)
#define ACC_VER         "1.8"
#endif
 
#if defined (C_MODEL)
#define PRINTF      printf
#define TF_ERROR    printf
#define TF_GETTIME()    0L
#else
#define PRINTF      io_printf
#define TF_ERROR    tf_error
#define TF_GETTIME  tf_gettime
#endif

/*----------------------------------------------------------*/
/* Queue data structures. */

/* Data Q element for transactionCtx Q. */
typedef struct transactionCtxQDataNode
{
	unsigned int streamId, saveNotRetrieve;
} transactionCtxQDataStructType, *transactionCtxQDataPtrType;

/* Data Q element for transaction Q. */
typedef struct transactionQDataNode
{
	unsigned int streamId, adrHi, adr, rdNotWrt, cmd, wrdSize;
} transactionQDataStructType, *transactionQDataPtrType;

/* Data Q element for write data Q. */
typedef struct wrtDataQDataNode
{
	unsigned int data, be_;
} wrtDataQDataStructType, *wrtDataQDataPtrType;

/* Data Q element for read data Q. */
typedef struct rdDataQDataNode
{
	unsigned int data;
} rdDataQDataStructType, *rdDataQDataPtrType;

/* Data Q element for read done Q. */
typedef struct rdDoneQDataNode
{
	unsigned int wrdSize;
} rdDoneQDataStructType, *rdDoneQDataPtrType;

/* Data Q element for read req Q. */
typedef struct rdReqQDataNode
{
	unsigned int wrdSize;
} rdReqQDataStructType, *rdReqQDataPtrType;

/* Data Q element for wait Q. */
typedef struct waitQDataNode
{
	unsigned int streamId, clks;
} waitQDataStructType, *waitQDataPtrType;

/*----------------------------------------------------------*/
/* Other data structures. */

/* One data node that contains the sync cnt associated with a type and
	a syncFlag associated with a type and streamId.  The structure
	is used in two contexts. */
typedef struct syncOtherDataNode
{
	unsigned int syncCnt, syncFlag;
} syncOtherDataStructType, *syncOtherDataPtrType;

/*----------------------------------------------------------*/
/* Fundamental queue structure. */

/* One node in the queue. */
typedef struct QNode
{
	char *QDataPtr;
	struct QNode *next, *prev;
} QStructType, *QPtrType;

/*----------------------------------------------------------*/
/* Structure to maintain context switch data. */
typedef struct QCtxNode
{
	unsigned int ctxCnt, oldQPtrValid;
	struct nodeStreamIdNode *ctxCntNodeStreamIdPtr;
	struct nodeStreamIdNode *stackNodeStreamIdPtr;
	struct nodeStreamIdNode *oldQPtrNodeStreamIdPtr;
} QCtxStructType, *QCtxPtrType;

/*----------------------------------------------------------*/
/* Linked list structures. */

/* One node that keeps track of a Q associated with a node and/or
	streamId. */
typedef struct nodeStreamIdNode
{
	unsigned int node, streamId;
	char *otherDataPtr;
	struct QNode *QPtr;
	struct QCtxNode *QCtxPtr;
	struct nodeStreamIdNode *next;
} nodeStreamIdStructType, *nodeStreamIdPtrType;


