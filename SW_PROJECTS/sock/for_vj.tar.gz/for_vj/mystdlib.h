#ifndef _MYSTDLIB_H_
#define _MYSTDLIB_H_
#ifndef FALSE
#	define  FALSE   (0)
#endif
 
#ifndef TRUE
#	define  TRUE    (1)
#endif
 
#define STR_LENGTH	256

#include <stdio.h>

/*----------------------------------------------------*/
/* Structure that contains parsed information. */

typedef struct parse_cell
{
	int num;
	char *str;
} PARSE_CELL_STRUCT, *PARSE_CELL_PTR;

/*----------------------------------------------------*/
/* Structure for command line dictionary. */
#define FLAG_TYPE	0
#define INT_TYPE	1
#define STRING_TYPE	2

typedef struct dict_cell
{
	char *word;
	int type;
} DICT_CELL_STRUCT;

/*----------------------------------------------------*/
/* Structure for parse_string arguments. */
typedef struct arg_cell
{
	char **argv;
	int argc;
} ARG_CELL_STRUCT, *ARG_CELL_PTR;

/*----------------------------------------------------*/
extern ARG_CELL_PTR init_arg_cell_ptr(void);
extern char *init_string(int length);
extern char *reinit_string(char *old_str_ptr, int length);
extern void free_string_array(char **str_array_ptr, int length);
extern char **init_string_array(int length);
extern char **reinit_string_array(char *old_str_array_ptr, int length);
extern int *init_integer_array(int length);
extern int *reinit_integer_array(int *old_int_array_ptr, int length);
extern int isodigit(char digit);
extern int myatoi(char *str);
extern int myatoi2(char *str, int *ret_value);
extern int myisalnum(char one_char);
extern FILE *open_file(char *file_name, char *access);
extern void create_dir(char *dir_name);
extern char *strsave(const char *string);
extern char *word_to_upper(char *str);
extern char *word_to_lower(char *str);
extern char *btoa(char *str, int bin_val, int digits);
extern char *htoa(char *str, int hex_val, int digits);
extern char *strcatsave(char *str1, char *str2);
extern int lookup(char *str, DICT_CELL_STRUCT dict[]);
extern PARSE_CELL_PTR *init_parse_cell_ptr(DICT_CELL_STRUCT dict[]);
extern void free_parse_cell_ptr(PARSE_CELL_PTR *parse_info_ptr, DICT_CELL_STRUCT dict[]);
extern unsigned int roll(unsigned int from, unsigned int to);
extern void parse(int argc, char *argv[], DICT_CELL_STRUCT dict[], PARSE_CELL_PTR *parse_info_ptr, void (*usage)());
extern int div_ceiling(int num1, int num2);
extern char *strstrcmp(char *str1, char *str2);
extern char *substr(char *str, int start_pos, int length);
extern char *last_path_element(char *str);
extern void free_arg_cell_ptr(ARG_CELL_PTR arg_cell_ptr);
extern int isfieldchar(char *field_str, char one_char);
extern ARG_CELL_PTR split(char *str, char *field_str, int cnt);
extern char *strip_end_whitespaces(char *str);
extern char *strip_begin_whitespaces(char *str);
extern char *sub(char *str1, char *str2, char *full_str);
extern char *sub2(char *str1, char *str2, char **full_str);
extern char *strsub(char *str1, char *str2, char *full_str);
extern char *mymktemp(char *str);
extern int pathcmp(char *path1, char *path2);
extern char *fgets_until(FILE *file_ptr, char *field_str);
extern char *sgets_until(char *str, char *field_str);

#endif /* #ifdef _MYSTDLIB_H_ */
