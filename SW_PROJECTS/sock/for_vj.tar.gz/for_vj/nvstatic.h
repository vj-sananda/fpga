#ifndef _NVSTATIC
#define _NVSTATIC

/*************************************************************************** 
 *                                                                         * 
 *  nvstatic.h  handle SPARC dependencies and X86 dependencies.            * 
 *                                                                         * 
 ***************************************************************************/

#if 0  /* MESSAGE */

Subject: Intel versus Sparc programming issues

Here is a list of some of the issues anyone interested in writing
portable code could run into.  This is by no means complete (the issues
off the top of my head).  Hopefully this list can eliminate many
portability problems.

Al.




I. Sparc and Intel Compilers define data type issues
----------------------------------------------------

 Datatype              value            architecture
  int              signed 16 bits        16-bit Intel
  int              signed 32 bits        32-bit Intel
  int              signed 32 bits           Sparc
  long             signed 32 bits           both
  unsigned long    unsigned 32 bits         both
  short            signed 16 bits           both
  unsigned short   unsigned 16 bits         both
  char             signed 8 bits            both

Rule of thumb:  Never use 'int'.

II. Endian issues
-----------------

  Long word
    Intel uses little endian:  B3 B2 B1 B0
    Sparc uses big endian:     B0 B1 B2 B3
  Short word
    Intel uses little endian:  S1 S0
    Sparc uses big endian:     S0 S1
  Char

Example:

test()
{

  int i;
  long lbuf[1];
  char *c;
  short *s;
  lbuf[0] = 0x44332211L;   /* the 'L' at the end is absolutely
                              necessary */
  c = (char*) lbuf;

  for(i=0;i<4;i++)
    printf ("%2x",(int)c[i]);
  printf ("\n");

  s = (short*) lbuf;

  for(i=0;i<2;i++)
    printf ("%4x\n",(int)s[i]);

}


Produces:

44332211
4433
2211  in Sparc

11223344
2211
4433  in Intel


III. Structures and bitfield issues
-----------------------------------

Rule of thumb:  DO NOT USE UNIONS OR STRUCTURES

1. Structures are not guaranteed to fill in byte boundaries.
Example:
  struct {
    unsigned int red : 10;
    unsigned int grn : 10;
    unsigned int blu : 10;
    unsigned int pad :  2;
  } colors;

Sparc fills to 4 bytes.
Watcom compiler supports user controlled variable packing, default
        is 4 bytes.

Microsoft Visual C++ fills to *6 bytes*.

2. Only use unions or structures if they are 16 bit aligned.

3. Bitfields are reversed with in structs.

Intel counts  31..0
Sparc counts  0..31

Example:
test3()
{
  struct {
    unsigned int b0 : 1;
    unsigned int b1 : 1;
    unsigned int b2 : 1;
    unsigned int b3 : 1;
    unsigned int S  : 28;
  } bits;

   *(long*)&bits = 0L;
   bits.b0 = 1;

   printf("0x%lx\n", *(long*)&bits);
}

Intel produces 0x1.
Sparc produces 0x80000000.

4. SPARCworks does not handle shift constant 0x8000000 like all
   other compilers.

r1 = 0x80000000 >> n;  /* SPARCworks signed shift, all others unsigned */

Best to use,

  for (BitCount=31;BitCount>=0;BitCount--)
        fprintf(fp,"%c", Data&(0x1L<<BitCount)?'1':'0' );

versus,

  for (BitCount=0;BitCount<32;BitCount++)
        fprintf(fp,"%c", Data&(0x80000000>>BitCount)?'1':'0' );

IV. Printf issues

16-bit Intel:
 '%ld' used when printing long words.  Using %ld when passing a short
  variable will expect a 32 bit double word and can/will cause alignment errors.
 '%d'  used when printing short words.  Using %d when passing a long
  variable will expect a 16 bit word and can/will cause alignment errors.

V. Macro expansion issues

1.  passing in conversions to strings

#if sparc
/* Sparc */
#define prt(nn)  printf("%s=%d\n", "nn", nn);
#else
/* Gnu, Intel and ANSI */
#define prt(nn)  printf("%s=%d\n", #nn, nn);
#endif

This also implies that SPARCworks does not understand the ANSI #nn.

r0 = 0x12345678L;
prt(r0);

Rule of thumb:  When in doubt with any construct portability issue,
                wrap it in a macro.

VI. Memory allocation issues

1. Intel requires explicit declaration of 'far' pointers when accessing
memory above the conventional memory space.  Sparc does not have this
concept and follows virtual memory constraints.

2. malloc

Intel:
malloc() generally only works in 64K chunks.

VII.  Pixel formats
Monochrome pixels in a 32-bit register are stored differently between Sparc
and Intel. Pixel 0 is the leftmost

CGA6
-----
  bit               bit
   31                 0  pixel #

  24-31 16-23 8-15 0-7

Sparc
------
  bit               bit
   31                 0
    0        -       31  pixel #
   

in a 32 bit register

VIII.

when opening files, Intel does not assume binary.  an explicit
call to open or fopen requires O_BINARY and 'b' added to the
mode line.

example:
  fopen("filename", "wb+");  /* opens a binary file for writing */
  open("filename", O_CREAT|O_BINARY);

VIII.  Final reminder

The compiler shipped with all Suns are not ANSI compatible!  :-)

#endif  /* MESSAGE */



/*************************************************************************** 
 *                                                                         * 
 *         DEFINITIONS                                                     * 
 *                                                                         * 
 ***************************************************************************/

#include 	"types3d.h"
/* 
   there is only one place for type defintion --> types3d.h
   the following type defintions are left for backward compatibility
*/

#if sparc
typedef char    S004d4;
typedef short   S004d8, S012d4;
typedef long    S012d8, S013d8;
#else
typedef signed char  S004d4;
typedef signed short S004d8, S012d4;
typedef signed long  S012d8, S013d8;
#endif

typedef unsigned char   U004d4;
typedef unsigned short  U012d4, U000d16;
typedef unsigned long   U012d8, U013d8, U000d24;

typedef unsigned long	BOOL;
typedef void		VOID;

typedef V032		NvObject;  /* Object names are 32 arbitrary bits */
 
#ifdef __STDC__ /* ansi c */
#define SRAND032(seed)	(srand(seed))
#define RAND032		((rand()<<20) ^ \
			 (rand()<< 8) ^ \
			 (rand()>> 4))
#endif

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif /* TRUE */

#endif /* _NVSTATIC */

