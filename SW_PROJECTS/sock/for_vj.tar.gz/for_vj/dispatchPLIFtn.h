#ifdef __cplusplus
extern "C" {
#endif

extern int SizePLI ();
extern int DirectRdPLI ();
extern int DirectWrtPLI ();
extern int Map ();
extern int IsMapped ();
extern int DisplayNodeList ();
extern int ExtractNumStreamsPLI ();
extern int ConnectSocketPLI ();
extern int ReceiveSocketPLI ();
extern int SendSocketPLI ();
extern int ExtractSocketPacketCommandPLI ();
extern int ExtractSocketPacketIntegerPLI ();
extern int BuildSocketPacketCommandPLI ();
extern int BuildSocketPacketIntegerPLI ();
extern int DisplaySocketPacketStringPLI ();
extern int CloseSocketPLI ();

unsigned int direct_read ( char *node_name, unsigned int offset, int type);

#ifdef __cplusplus
}
#endif
